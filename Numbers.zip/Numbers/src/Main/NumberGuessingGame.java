package Main;

public class NumberGuessingGame {
    private int secretNumber;
    private int attempts;

    public void initializeGame() {
        secretNumber = (int) (Math.random() * 100) + 1;
        attempts = 0;
    }

    public String processGuess(int guess) {
        attempts++;

        if (guess < secretNumber) {
            return "Too low! Try again.";
        } else if (guess > secretNumber) {
            return "Too high! Try again.";
        } else {
            return "Congratulations! You've guessed the number in " + attempts + " attempts.";
        }
    }
}

